package com.example.conectorbasededatos;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class HelloController {
    private ObservableList<Oficina>oficinaLista=FXCollections.observableArrayList();
    private Oficina ofAux;
    @FXML
    private TableView tvDatos;
    @FXML
    private Button cargar;
    @FXML
    private TableColumn officeCode;
    @FXML
    private TableColumn city;
    @FXML
    private TableColumn phone;
    @FXML
    private TableColumn addressLine1;
    @FXML
    private TableColumn addressLine2;
    @FXML
    private TableColumn state;
    @FXML
    private TableColumn country;
    @FXML
    private TableColumn postalCode;
    @FXML
    private TableColumn territory;

    private Oficina auxOf;
    @FXML
    Connection c;


    public void Conectar(){

        try{
            c = DriverManager.getConnection("jdbc:mariadb://localhost:5555/noinch?useSSL=false"
                    ,"adminer",
                    "adminer");


            ResultSet rs = c.createStatement().executeQuery("Select * from offices");


            while (rs.next()) {
                auxOf=new Oficina(
                        rs.getString("officeCode"),
                        rs.getString("city"),
                        rs.getString("phone"),
                        rs.getString("addressLine1"),
                        rs.getString("addressLine2"),
                        rs.getString("state"),
                        rs.getString("country"),
                        rs.getString("postalCode"),
                        rs.getString("territory")
                );
                oficinaLista.add(auxOf);
                System.out.println("Row [1] added " + auxOf.toString());
            }

            officeCode.setCellValueFactory(new PropertyValueFactory<Oficina, String>("officeCode"));
            city.setCellValueFactory(new PropertyValueFactory<Oficina, String>("city"));
            phone.setCellValueFactory(new PropertyValueFactory<Oficina, String>("phone"));
            addressLine1.setCellValueFactory(new PropertyValueFactory<Oficina, String>("addressLine1"));
            addressLine2.setCellValueFactory(new PropertyValueFactory<Oficina, String>("addressLine2"));
            state.setCellValueFactory(new PropertyValueFactory<Oficina, String>("state"));
            country.setCellValueFactory(new PropertyValueFactory<Oficina, String>("country"));
            postalCode.setCellValueFactory(new PropertyValueFactory<Oficina, String>("postalCode"));
            territory.setCellValueFactory(new PropertyValueFactory<Oficina, String>("territory"));

            tvDatos.setItems(oficinaLista);

            c.close();
        }
        catch(Exception e){
            e.printStackTrace();
            tvDatos.getColumns().clear();
            tvDatos.setItems(null);
            System.out.println("Error on Building Data");
        }

    }

    public void altaOficina(ActionEvent actionEvent){
        int registrosAfectadoConsulta = 0;
        try {
            c = DriverManager.getConnection("jdbc:mariadb://localhost:5555/noinch?useSSL=false"
                    , "adminer",
                    "adminer");

            String SQL = "INSERT INTO offices("
                    +"officeCode ,"
                    +"city ,"
                    +"phone ,"
                    +"addressLine1 ,"
                    +"addressLine2 ,"
                    +"state ,"
                    +"country ,"
                    +"postalCode ,"
                    +"territory )"
                    +"VALUES (inboxOfficeCode.getText(),inboxCity.getText(),inboxPhone.getText(),inboxAdress1.getText, " +
                    "inboxAdress2.getText(),inboxState.getText(),inboxCountry.getText(),inboxPostalCode.getText(),inboxTerritory.getText())";
            PreparedStatement st = c.prepareStatement(SQL);
            registrosAfectadoConsulta = st.executeUpdate();
            st.close();
            c.close();

        }catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error:" + e.toString());
        }
    }
}